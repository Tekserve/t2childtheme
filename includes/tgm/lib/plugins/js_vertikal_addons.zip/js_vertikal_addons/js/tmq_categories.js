jQuery(function($) {
	$('.blog_category_selector').find('select').on('change', function() {
		var selected_cats = [];
		$('.blog_category_selector').find('select :selected').each(function (i, selected) {
			selected_cats[i] = $(selected).val();
		});
		var blog_cats_val = selected_cats.join(',');
		$('.blog_category_selector').find('input').val(blog_cats_val);
	});
});