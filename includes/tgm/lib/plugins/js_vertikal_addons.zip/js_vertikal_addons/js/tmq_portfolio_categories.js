jQuery(function($) {
	$('.portfolio_category_selector').find('select').on('change', function() {
		var selected_deps = [];
		$('.portfolio_category_selector').find('select :selected').each(function (i, selected) {
			selected_deps[i] = $(selected).val();
		});
		var portfolio_cat_values = selected_deps.join(',');
		$('.portfolio_category_selector').find('input').val(portfolio_cat_values);
	});
});