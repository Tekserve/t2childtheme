jQuery(function($) {
	$('.department_selector').find('select').on('change', function() {
		var selected_deps = [];
		$('.department_selector').find('select :selected').each(function (i, selected) {
			selected_deps[i] = $(selected).val();
		});
		var departments_values = selected_deps.join(',');
		$('.department_selector').find('input').val(departments_values);
	});
});