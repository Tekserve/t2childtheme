<?php
/*
Plugin Name: Vertikal Premium Theme Add-ons
Plugin URI: http://www.themeforest.net/user/imangm
Description: This plugin will extend Visual Composer Page Builder to suit Vertikal WP Theme.
Version: 1.7
Author: Iman G.M.
Author URI: http://www.themeforest.net/user/imangm
*/

// Translate Ready
function tmq_lang() {
	load_plugin_textdomain( 'vertikal_plugin', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
}
add_action('init', 'tmq_lang');

function tmq_load_admin_scripts() {
	wp_register_style('tmq_backend', plugin_dir_url( __FILE__ ) . '/css/main.css', array(), '1.0', 'screen');
	wp_register_style('tmq-fontawesome', plugin_dir_url( __FILE__ ) . '/css/font-awesome.css', array(), '1.0', 'screen');
	wp_enqueue_style('tmq_backend');
	wp_enqueue_style('tmq-fontawesome');
}
add_action('admin_enqueue_scripts', 'tmq_load_admin_scripts'); // Add BackEnd Stylesheet

include('post-types/post-types.php');
include('widgets/magic-widget.php');

add_action( 'vc_before_init', 'VertikalWithVC' );


// Initialize Vertikal ShortCodes
function VertikalWithVC() {
	/* ======================================================
	// HR
	====================================================== */
	if ( function_exists( 'vc_map' ) ) {
		if ( !function_exists('getCSSAnimation') ) {
			function getCSSAnimation( $css_animation ) {
				$output = '';
				if ( $css_animation != '' ) {
					wp_enqueue_script( 'waypoints' );
					$output = ' wpb_animate_when_almost_visible wpb_'.$css_animation;
				}
				return $output;
			}
		}

		$add_css_animation = array(
			'type' 			=> 'dropdown',
			'heading' 		=> 'CSS Animation',
			'param_name' 	=> 'css_animation',
			'admin_label' 	=> true,
			'value' 		=> array(
				'No' 					=> '',
				'Top to bottom' 		=> 'top-to-bottom',
				'Bottom to top' 		=> 'bottom-to-top',
				'Left to right' 		=> 'left-to-right',
				'Right to left' 		=> 'right-to-left',
				'Appear from center'	=> 'appear'
			),
			'description' 	=> 'Select animation type if you want this element to be animated when it enters into the browsers viewport. Note: Works only in modern browsers.'
		);

		function tmq_HR( $atts, $content=null ) {
			$hr = '<hr>';
			return $hr;
		}
		add_shortcode( 'tmq_hr', 'tmq_HR' );

		vc_map( 
			array(
				'name' 						=> 'Horizontal Divider',
				'base' 						=> 'tmq_hr',
				'class' 					=> '',
				'category' 					=> 'Content',
				'controls'					=> 'popup_delete',
				'weight'					=> 10,
				'description' 				=> 'Horizontal Line - HR tag',
				'icon'						=> 'icon-wpb-tmq_hr',
				'admin_enqueue_css' 		=> array(plugin_dir_url( __FILE__ ).'/css/tmq_vc_icons.css'),
				'show_settings_on_create' 	=> false
			)
		);

		/* ======================================================
		// Vertical Spacer (Gap)
		====================================================== */
		function tmq_Gap( $atts, $content=null ) {
			extract( shortcode_atts( 
				array(
					'size' 	=> '40',
				), $atts)
			);
			if ( !is_numeric( $size ) ) {
				$size = 40;
			} else {
				if ( $size < 0 || $size > 200 ) {
					$size = 40;
				}
			}		
			$gap = '<div class="clearfix" style="height: ' . $size . 'px"></div>';
			return $gap;
		}
		add_shortcode( 'tmq_gap', 'tmq_Gap' );  

		vc_map(
			array(
				'name' 			=> 'Gap',
				'base' 			=> 'tmq_gap',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Vertical space in content',
				'admin_label'	=> true,
				'icon'						=> 'icon-wpb-tmq_gap',
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Insert a Vertical Gap',
					  'param_name' 		=> 'size',
					  'admin_label'		=> true,
					  'value' 			=> '40',
					  'description' 	=> 'Enter the gap size in pixels. It should be between 0 and 200 pixels'
					)
				)
			)	
		);

		/* ======================================================
		// Progress bar
		====================================================== */
		function tmq_progressbar( $atts, $content=null ) {
			extract( shortcode_atts( 
				array(
					'title'			=> '',
					'values'   		=> '',
					'css_animation' => ''
				), $atts)
			);
			$css_class = getCSSAnimation( $css_animation );
			$progressbar = '<div class="skills-progress '. $css_class .'">';
			
			if ( !empty( $title ) ) {
				$progressbar .= '<h3>'. $title .'</h3>';
			}
			
			$progressbars = explode( ',', $values );
			// What if user entered a wrong value there?!
			if ( is_array( $progressbars ) && count( $progressbars ) > 1 ) {
				foreach ( $progressbars as $progressbar_item ) {
					$progressbar_item_fields = explode ( '|', $progressbar_item );
					if ( is_array( $progressbar_item_fields ) && count( $progressbar_item_fields ) > 1 ) {
						if ( is_numeric( $progressbar_item_fields[0] ) ) {
							$progressbar .= '<p>' . $progressbar_item_fields[1] . '<span>' . $progressbar_item_fields[0] . '%</span></p>';
							$progressbar .=	'<div class="meter nostrips photoshop">
												<span style="width: ' . $progressbar_item_fields[0] . '%"></span>
											</div>';
						}
					}
				}
			}
			
			$progressbar .= '</div>';
			
			return $progressbar;
		}
		add_shortcode( 'tmq_progressbar', 'tmq_progressbar' ); 

		vc_map( 
			array(
				'name' 				=> 'Progress Bar',
				'base' 				=> 'tmq_progressbar',
				'category' 			=> 'Content',
				'weight'			=> 10,		
				'description' 		=> 'Add several progress bar',
				'icon'				=> 'icon-wpb-tmq_progressbar',
				'params' 			=> array(
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Title',
						'param_name' 	=> 'title',
						'admin_label'	=> true,
						'description' 	=> 'What text use as a title. Leave blank if no title is needed.'
					),
					array(
						'type' 			=> 'exploded_textarea',
						'heading' 		=> 'Progress bars values',
						'param_name' 	=> 'values',
						'description' 	=> 'Input graph values here. Divide values with linebreaks (Enter). Example: 90|Development',
						'value' 		=> '90|Development,80|Design,70|Marketing'
					),
					$add_css_animation
				)
			) 
		);

		
		/* ======================================================
		// Review element
		====================================================== */
		function tmq_review( $atts, $content=null ) {
			extract( shortcode_atts( 
				array(
					'title'				=> 'Excellent!',
					'values'   			=> '',
					'review_overview' 	=> '',
					'rating'			=> '8.5',
					'css_animation' 	=> ''
				), $atts)
			);
			$css_class = getCSSAnimation( $css_animation );
			$reviewblock = '<div class="review-box '. $css_class .'">';
			
				$reviewblock .= '<div class="review-overall">
						<div class="review-overall-rating">Overall Rating</div>
						<div class="review-rate">' . $rating .'</div>
					</div>
					<div class="review-overview">
						<h4>' . $title .'</h4>
						<p>' . $review_overview .'</p>
					</div>
					<div class="clearfix"></div>
				</div>';
					

			
			if ( !empty( $values ) ) {
				$reviewblock .= '<div class="review-ratings">
							<div class="skills-progress">
								<h4>Review Overview</h4>
								<hr>';
							$progressbars = explode( ',', $values );
							// What if user entered a wrong value there?!
							if ( is_array( $progressbars ) && count( $progressbars ) > 1 ) {
								foreach ( $progressbars as $progressbar_item ) {
									$progressbar_item_fields = explode ( '|', $progressbar_item );
									if ( is_array( $progressbar_item_fields ) && count( $progressbar_item_fields ) > 1 ) {
										if ( is_numeric( $progressbar_item_fields[0] ) ) {
											$reviewblock .= '<p>' . $progressbar_item_fields[1] . '<span>' . $progressbar_item_fields[0] . '%</span></p>';
											$reviewblock .=	'<div class="meter nostrips photoshop">
																<span style="width: ' . $progressbar_item_fields[0] . '%"></span>
															</div>';
										}
									}
								}
							}
							
							$reviewblock .= '</div></div>';							
			}
			
			return $reviewblock;
		}
		add_shortcode( 'tmq_review', 'tmq_review' ); 

		vc_map( 
			array(
				'name' 				=> 'Review Block',
				'base' 				=> 'tmq_review',
				'category' 			=> 'Content',
				'weight'			=> 10,		
				'description' 		=> 'Add a review block on your page',
				'icon'				=> 'icon-wpb-tmq_review',
				'params' 			=> array(
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Rating Title',
						'param_name' 	=> 'title',
						'admin_label'	=> true,
						'description' 	=> 'Enter review title here. Such as Very Good! Fantastic! Awesome!'
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Overall Rating',
						'param_name' 	=> 'rating',
						'admin_label'	=> true,
						'description' 	=> 'Rate it here from 0 to 10'
					),
					array(
						'type' 			=> 'textarea',
						'heading' 		=> 'Review Overview Text',
						'param_name' 	=> 'review_overview',
						'admin_label'	=> false,
						'description' 	=> 'Tell what you feel about what you have reviewed in this page in a few words'
					),
					array(
						'type' 			=> 'exploded_textarea',
						'heading' 		=> 'Progress bars values',
						'param_name' 	=> 'values',
						'description' 	=> 'Input graph values here. Divide values with linebreaks (Enter). Example: 90|Development',
						'value' 		=> '90|Development,80|Design,70|Marketing'
					),
					$add_css_animation
				)
			) 
		);
		
		/* ======================================================
		// Tag List
		====================================================== */
		function tmq_taglist( $atts, $content=null ) {
			extract( shortcode_atts( 
				array(
					'values'   		=> '',
					'popup'			=> '0',
					'css_animation' => ''
				), $atts)
			);
			
			if ( $popup == '1' ) {
				$target = '_blank';
			} else {
				$target = '_self';
			}
			$css_class = getCSSAnimation( $css_animation );
			$taglist = '<ul class="tag-list '. $css_class .'">';
			
			$tmq_tags = explode( ',', $values );

			if ( is_array( $tmq_tags ) && count( $tmq_tags ) > 1 ) {
				foreach ( $tmq_tags as $tag_item ) {
					$tag_item_fields = explode ( '|', $tag_item );
					if ( is_array( $tag_item_fields ) && count( $tag_item_fields ) > 1 ) {
						$taglist .=	'<li><a href="' . $tag_item_fields[1] . '" target="' . $target . '"><i class="fa fa-check-circle"></i>' .  $tag_item_fields[0] . '</a></li>';
					}
				}
			}
			
			$taglist .= '</ul>';
			
			return $taglist;
		}
		add_shortcode( 'tmq_taglist', 'tmq_taglist' ); 

		vc_map( 
			array(
				'name' 			=> 'Tag List',
				'base' 			=> 'tmq_taglist',
				'category' 		=> 'Content',
				'weight'		=> 10,		
				'description' 	=> 'Stylish list of items and services',
				'icon'						=> 'icon-wpb-tmq_taglist',
				'params' => array(
					array(
						'type' 			=> 'exploded_textarea',
						'heading' 		=> 'List of Tags',
						'param_name' 	=> 'values',
						'description' 	=> 'Enter the list of tags and their links. Divide values with linebreaks (Enter). Example: Custom Development|http://www.themique.com/',
						'value' 		=> 'Custom Development|http://www.themique.com,Cute Design|http://www.themeforest.net,Another Tag|#'
					),
					array(
						'type' 			=> 'checkbox',
						'heading' 		=> 'Open link in new window',
						'param_name'	=> 'popup',
						'value' 		=> array('Yes Please!' => true )
					),
					$add_css_animation			
				)
			) 
		); 

		/* ======================================================
		// Services
		====================================================== */
		function tmq_services($atts, $content=null) {
			extract(shortcode_atts(
				array(
					'title'  		=> '',
					'link'	 		=> '',
					'popup'  	 	=> '0',
					'icon'   		=> '',
					'css_animation' => ''
				), $atts)
			); 
			
			$services = '';
			
			if ( $popup == '1' ) {
				$target = '_blank';
			} else {
				$target = '_self';
			}
			
			$css_class = getCSSAnimation( $css_animation );
			
			$services .= '<div class="services-post '. $css_class .'">';
			$services .= "\n\t" . '<a class="services-icon1" href="' . $link . '" target="' . $target . '"><i class="fa ' . $icon . '"></i></a>';
			$services .= "\n\t" . '<div class="services-post-content">';
			$services .= ( empty( $title ) ? '' : "\n\t\t" . '<a class="services-title-link" href="' . $link . '" target="' . $target . '"><h4>' . $title . '</h4></a>' );
			$services .= "\n\t\t" . '<p>' . $content . '</p>';
			$services .= "\n\t" . '</div>';
			$services .= '</div>';
			
			return $services;
		}
		add_shortcode("tmq_services", "tmq_services");  

		vc_map( 
			array(
				'name' 			=> 'Iconned Service',
				'base' 			=> 'tmq_services',
				'category' 		=> 'Content',
				'weight'		=> 10,		
				'description' 	=> 'Iconned service element',
				'icon'			=> 'icon-wpb-tmq_services',
				'params' => array(
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Title',
						'param_name' 	=> 'title',
						'description' 	=> 'What text use as a title. Leave blank if no title is needed.',
						'value'			=> 'Title',
						'admin_label'	=> true,
					),
					array(
						'type' 			=> 'tmq_icon_select',
						'heading' 		=> 'Icon',
						'param_name' 	=> 'icon',
						'description' 	=> 'Choose the icon from Icon gallery.',
						'value' 		=> 'fa-cogs'
					),
					array(
						'type' 			=> 'textarea',
						'heading' 		=> 'Content',
						'param_name' 	=> 'content',
						'description' 	=> 'Enter the text of the service element',
						'value' 		=> 'This is a service element and here is the content!'
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Link',
						'param_name' 	=> 'link',
						'description' 	=> 'The URL of the page that user will be redirect once he/she clicks on the service element icon.',
						'value' 		=> '#'
					),    
					array(
						'type' 			=> 'checkbox',
						'heading' 		=> 'Open link in new window',
						'param_name'	=> 'popup',
						'value' 		=> array('Yes Please!' => true )
					),
					$add_css_animation
				)
			) 
		); 

		/* ======================================================
		// Promo Box
		====================================================== */
		function tmq_promobox($atts, $content=null) {
			extract(shortcode_atts(
				array(
					'title'  		=> '',
					'link'	 		=> '',
					'popup'  	 	=> '0',
					'button_text' 	=> '',
					'css_animation' => '',
					'button_color'  => 'normal'
				), $atts)
			); 
			
			$promobox = '';
			
			if ( $popup == '1' ) {
				$target = '_blank';
			} else {
				$target = '_self';
			}
			
			$buttoncolor = '';
			if ( $button_color == 'calltoaction' ) {
				$buttoncolor = ' green';
			} elseif ( $button_color == 'alert' ) {
				$buttoncolor = ' orange';
			}
			
			$css_class = getCSSAnimation( $css_animation );
			
			// $promobox .= '<div class="services-post '. $css_class .'">';
			// $promobox .= "\n\t" . '<a class="services-icon1" href="' . $link . '" target="' . $target . '"><i class="fa ' . $icon . '"></i></a>';
			// $promobox .= "\n\t" . '<div class="services-post-content">';
			// $promobox .= ( empty( $title ) ? '' : "\n\t\t" . '<h4>' . $title . '</h4>' );
			// $promobox .= "\n\t\t" . '<p>' . $content . '</p>';
			// $promobox .= "\n\t" . '</div>';
			// $promobox .= '</div>';
			
			$promobox .= '
				<div class="promo-box '. $css_class .'">
					<div class="promo-text">
						<h3>'. $title .'</h3>
					</div>
					<div class="promo-button">
						<a class="tmq_button '. $buttoncolor .' default wpb_regularsize pull-left" href="'. $link .'" target="'. $target .'">'. $button_text .'</a>
					</div>
				</div>
			';
			
			return $promobox;
		}
		add_shortcode("tmq_promobox", "tmq_promobox");  

		vc_map( 
			array(
				'name' 			=> 'Promo Box',
				'base' 			=> 'tmq_promobox',
				'category' 		=> 'Content',
				'weight'		=> 10,		
				'description' 	=> 'Add a call to action block',
				'icon'			=> 'icon-wpb-tmq_promobox',
				'params' => array(
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Title',
						'param_name' 	=> 'title',
						'description' 	=> 'Enter the text of your call to action block.',
						'value'			=> 'Call to Action',
						'admin_label'	=> true,
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Button Text',
						'param_name' 	=> 'button_text',
						'description' 	=> 'Text of the button',
						'value' 		=> 'Buy Now!'
					),			
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Button Color',
					  'param_name' 		=> 'button_color',
					  'holder' 			=> 'div',
					  'admin_label' 	=> false,
					  'value' 			=> array( 'Normal' => 'normal', 'Call to Action' => 'calltoaction', 'Alert' => 'alert' ),
					  'description' 	=> 'Choose the color of the button. Normal is the main theme color, Call to action is green and Alert is orange.'
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Link',
						'param_name' 	=> 'link',
						'description' 	=> 'The URL of the page that user will be redirect once he/she clicks on the button.',
						'value' 		=> '#'
					),    
					array(
						'type' 			=> 'checkbox',
						'heading' 		=> 'Open link in new window',
						'param_name'	=> 'popup',
						'value' 		=> array('Yes Please!' => true )
					),
					$add_css_animation
				)
			) 
		); 

		/* ======================================================
		// Iconned Tabs
		====================================================== */
		$tab_id_1 = time().'-1-'.rand(0, 100);
		$tab_id_2 = time().'-2-'.rand(0, 100);
		$tab_id_3 = time().'-3-'.rand(0, 100);
		vc_map(
			array(
				'name'  					=> 'Iconned Tabs',
				'base' 						=> 'tmq_tabs',
				'as_parent' 				=> array('only' => 'tmq_tab'),
				'show_settings_on_create' 	=> false,
				'category' 					=> 'Content',
				'weight'					=> 10,  
				'description' 				=> 'Tabbed content',
				'icon'						=> 'icon-wpb-tmq_tabs',
				'params' 					=> array(
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Tabs Block Title',
						'param_name' 	=> 'title',
						'description' 	=> 'What text use as a title. Leave blank if no title is needed.'
					),
					array(
						'type' 			=> 'checkbox',
						'heading' 		=> 'Navigation with Icons',
						'param_name'	=> 'icons',
						'value' 		=> array('Enabled' => true )
					),			
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Navigation Position',
					  'param_name' 		=> 'nav',
					  'holder' 			=> 'div',
					  'admin_label' 	=> true,
					  'value' 			=> array( 'Bottom' => 'bottom', 'Top' => 'top' ),
					  'description' 	=> 'Where do you want to see awesome tabs navigation?'
					),
				),
				'custom_markup' 			=> '
					<div class="wpb_tabs_holder wpb_holder vc_container_for_children">
					<ul class="tabs_controls">
					</ul>
					%content%
					</div>'
				,
				'default_content' 			=> '
					[tmq_tab title="Tab 1" tab_id="'.$tab_id_1.'" tab_icon="fa-cog"][vc_row_inner][vc_column_inner width="1/1"][/vc_column_inner][/vc_row_inner][/tmq_tab]
					[tmq_tab title="Tab 2" tab_id="'.$tab_id_2.'" tab_icon="fa-picture-o"][vc_row_inner][vc_column_inner width="1/1"][/vc_column_inner][/vc_row_inner][/tmq_tab]
					[tmq_tab title="Tab 3" tab_id="'.$tab_id_3.'" tab_icon="fa-leaf"][vc_row_inner][vc_column_inner width="1/1"][/vc_column_inner][/vc_row_inner][/tmq_tab]
				',
				'js_view'						=> 'VcColumnView'
			)
		);

		vc_map( 
			array(
				'name' 						=> 'Tab Content',
				'base' 						=> 'tmq_tab',
				'as_parent' 				=> array('except' => ''),
				'as_child' 					=> array('only' => 'tmq_tabs'),
				'content_element' 			=> true,
				'is_container' 				=> true,
				'weight'					=> 10,  
				'params'					=> array(
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Title',
						'param_name' 	=> 'title',
						'description' 	=> 'Tab title.',
						'admin_label'	=> true
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Tab ID',
						'param_name' 	=> 'tab_id'
					),
					array(
						'type' 			=> 'tmq_icon_select',
						'heading' 		=> 'Tab Icon',
						'param_name' 	=> 'tab_icon',
						'admin_label'	=> true
					)
				),
				'js_view'					=> 'VcColumnView'
			) 
		);
		
		/* Vertikal Awesome Tabs */
		if(class_exists('WPBakeryShortCodesContainer')) { 
			class WPBakeryShortCode_Tmq_Tabs extends WPBakeryShortCodesContainer { }
			class WPBakeryShortCode_Tmq_Tab extends WPBakeryShortCodesContainer { }
		}		

		/* ======================================================
		// Icons
		====================================================== */
		function tmq_icon( $atts, $content=null ) {
			extract( shortcode_atts( 
				array(
					'icon' 		=> 'fa-cogs',
					'size'		=> '0'
				), $atts)
			);
			$extra_class = '';
			if ( $size == 'small' ) {
				$extra_class = ' small';
			} elseif ( $size == 'large' ) {
				$extra_class = ' large';
			} else {
				$extra_class = '';
			}
			$icon = '<span class="awesome-icons' . $extra_class . '"><i class="fa ' . $icon . '"></i></span>';
			return $icon;
		}
		add_shortcode( 'tmq_icon', 'tmq_icon' );  

		function tmq_icon_select_settings_field( $settings, $value ) {
			$dependency = vc_generate_dependencies_attributes( $settings );
			$option = '';
			$tmq_icons_set = '';
			
			$tmq_icons_set .= '<div class="tmq-icon-container">';
			$tmq_icons_set .= '<input type="hidden" name="' . $settings['param_name'] . '" value="' . $value . '" class="wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . '_field" ' . $dependency . '>';
			$tmq_icons_set .= "\n\t" . '<div class="tabs-heading">';
			$tmq_icons_set .= "\n\t\t" . '<a href="#" id="new">New</a>';
			$tmq_icons_set .= "\n\t\t" . '<a href="#" id="web-apps">Web Apps</a>';
			$tmq_icons_set .= "\n\t\t" . '<a href="#" id="editor">Editor</a>';
			$tmq_icons_set .= "\n\t\t" . '<a href="#" id="directional">Directional</a>';
			$tmq_icons_set .= "\n\t\t" . '<a href="#" id="brands">Brands</a>';
			$tmq_icons_set .= "\n\t\t" . '<a href="#" id="other">Other</a>';
			$tmq_icons_set .= "\n\t" . '</div>';
			$tmq_icons_set .= "\n\t" . '<div class="iconslist">';
			$tmq_icons_set .= "\n\t\t" . '<ul data-page="new">';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bed"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-buysellads"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cart-arrow-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cart-plus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-connectdevelop"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dashcube"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-diamond"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-facebook-official"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-forumbee"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-heartbeat"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hotel"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-leanpub"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-double"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-stroke"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-stroke-h"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-stroke-v"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-medium"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mercury"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-motorcycle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-neuter"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pinterest-p"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sellsy"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-server"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ship"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-shirtsinbulk"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-simplybuilt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-skyatlas"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-street-view"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-subway"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-train"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-transgender"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-transgender-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user-plus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user-secret"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user-times"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-venus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-venus-double"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-venus-mars"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-viacoin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-whatsapp"></i></li>';
			$tmq_icons_set .= "\n\t\t" . '</ul>';
			$tmq_icons_set .= "\n\t\t" . '<ul data-page="web-apps">';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-adjust"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-anchor"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-archive"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-area-chart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows-h"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows-v"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-asterisk"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-at"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-automobile"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ban"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bank"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bar-chart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bar-chart-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-barcode"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bars"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bed"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-beer"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bell"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bell-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bell-slash"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bell-slash-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bicycle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-binoculars"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-birthday-cake"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bolt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bomb"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-book"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bookmark"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bookmark-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-briefcase"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bug"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-building"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-building-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bullhorn"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bullseye"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cab"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-calculator"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-calendar"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-calendar-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-camera"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-camera-retro"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-car"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cart-arrow-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cart-plus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-certificate"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-check"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-check-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-check-circle-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-check-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-check-square-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-child"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-circle-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-circle-o-notch"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-circle-thin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-clock-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-close"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cloud"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cloud-download"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cloud-upload"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-code"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-code-fork"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-coffee"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cog"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cogs"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-comment"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-comment-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-comments"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-comments-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-compass"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-copyright"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-credit-card"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-crop"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-crosshairs"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cube"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cubes"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cutlery"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dashboard"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-database"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-desktop"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-diamond"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dot-circle-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-download"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-edit"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ellipsis-h"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ellipsis-v"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-envelope"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-envelope-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-envelope-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-eraser"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-exchange"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-exclamation"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-exclamation-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-exclamation-triangle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-external-link"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-external-link-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-eye"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-eye-slash"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-eyedropper"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-fax"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-female"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-fighter-jet"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-archive-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-audio-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-code-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-excel-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-image-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-movie-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-pdf-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-photo-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-picture-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-powerpoint-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-sound-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-video-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-word-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-zip-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-film"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-filter"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-fire"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-fire-extinguisher"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-flag"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-flag-checkered"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-flag-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-flash"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-flask"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-folder"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-folder-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-folder-open"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-folder-open-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-frown-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-futbol-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gamepad"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gavel"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gear"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gears"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-genderless"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gift"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-glass"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-globe"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-graduation-cap"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-group"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hdd-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-headphones"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-heart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-heart-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-heartbeat"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-history"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-home"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hotel"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-image"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-inbox"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-info"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-info-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-institution"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-key"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-keyboard-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-language"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-laptop"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-leaf"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-legal"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-lemon-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-level-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-level-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-life-bouy"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-life-buoy"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-life-ring"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-life-saver"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-lightbulb-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-line-chart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-location-arrow"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-lock"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-magic"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-magnet"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mail-forward"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mail-reply"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mail-reply-all"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-male"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-map-marker"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-meh-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-microphone"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-microphone-slash"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-minus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-minus-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-minus-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-minus-square-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mobile"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mobile-phone"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-money"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-moon-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mortar-board"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-motorcycle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-music"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-navicon"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-newspaper-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paint-brush"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paper-plane"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paper-plane-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paw"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pencil"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pencil-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pencil-square-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-phone"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-phone-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-photo"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-picture-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pie-chart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plane"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plug"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plus-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plus-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plus-square-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-power-off"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-print"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-puzzle-piece"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-qrcode"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-question"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-question-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-quote-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-quote-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-random"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-recycle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-refresh"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-remove"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-reorder"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-reply"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-reply-all"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-retweet"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-road"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rocket"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rss"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rss-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-search"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-search-minus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-search-plus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-send"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-send-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-server"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-share"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-share-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-share-alt-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-share-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-share-square-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-shield"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ship"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-shopping-cart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sign-in"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sign-out"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-signal"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sitemap"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sliders"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-smile-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-soccer-ball-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-alpha-asc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-alpha-desc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-amount-asc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-amount-desc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-asc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-desc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-numeric-asc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-numeric-desc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sort-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-space-shuttle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-spinner"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-spoon"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-square-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-star"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-star-half"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-star-half-empty"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-star-half-full"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-star-half-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-star-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-street-view"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-suitcase"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sun-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-support"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tablet"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tachometer"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tag"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tags"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tasks"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-taxi"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-terminal"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-thumb-tack"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-thumbs-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-thumbs-o-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-thumbs-o-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-thumbs-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ticket"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-times"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-times-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-times-circle-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tint"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-off"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-on"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-trash"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-trash-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tree"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-trophy"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-truck"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tty"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-umbrella"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-university"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-unlock"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-unlock-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-unsorted"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-upload"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user-plus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user-secret"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user-times"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-users"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-video-camera"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-volume-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-volume-off"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-volume-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-warning"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-wheelchair"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-wifi"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-wrench"></i></li>';
			$tmq_icons_set .= "\n\t\t" . '</ul>';
			$tmq_icons_set .= "\n\t\t" . '<ul data-page="editor">';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-align-center"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-align-justify"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-align-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-align-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bold"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chain"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chain-broken"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-clipboard"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-columns"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-copy"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cut"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dedent"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-eraser"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-text"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-text-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-files-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-floppy-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-font"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-header"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-indent"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-italic"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-link"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-list"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-list-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-list-ol"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-list-ul"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-outdent"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paperclip"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paragraph"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paste"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-repeat"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rotate-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rotate-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-save"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-scissors"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-strikethrough"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-subscript"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-superscript"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-table"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-text-height"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-text-width"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-th"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-th-large"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-th-list"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-underline"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-undo"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-unlink"></i></li>';
			$tmq_icons_set .= "\n\t\t" . '</ul>';
			$tmq_icons_set .= "\n\t\t" . '<ul data-page="directional">';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-double-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-double-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-double-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-double-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angle-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-o-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-o-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-o-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-o-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-circle-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrow-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows-h"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows-v"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-square-o-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-caret-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-circle-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-circle-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-circle-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-circle-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-chevron-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hand-o-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hand-o-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hand-o-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hand-o-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-long-arrow-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-long-arrow-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-long-arrow-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-long-arrow-up"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-down"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-left"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-right"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-toggle-up"></i></li>';
			$tmq_icons_set .= "\n\t\t" . '</ul>';
			$tmq_icons_set .= "\n\t\t" . '<ul data-page="brands">';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-adn"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-android"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-angellist"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-apple"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-behance"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-behance-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bitbucket"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bitbucket-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bitcoin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-btc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-buysellads"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cc-amex"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cc-discover"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cc-mastercard"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cc-paypal"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cc-stripe"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cc-visa"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-codepen"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-connectdevelop"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-css3"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dashcube"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-delicious"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-deviantart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-digg"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dribbble"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dropbox"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-drupal"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-empire"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-facebook"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-facebook-f"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-facebook-official"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-facebook-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-flickr"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-forumbee"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-foursquare"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ge"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-git"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-git-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-github"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-github-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-github-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gittip"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-google"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-google-plus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-google-plus-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-google-wallet"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gratipay"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hacker-news"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-html5"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-instagram"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ioxhost"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-joomla"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-jsfiddle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-lastfm"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-lastfm-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-leanpub"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-linkedin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-linkedin-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-linux"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-maxcdn"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-meanpath"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-medium"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-openid"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pagelines"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-paypal"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pied-piper"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pied-piper-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pinterest"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pinterest-p"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pinterest-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-qq"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ra"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rebel"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-reddit"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-reddit-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-renren"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sellsy"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-share-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-share-alt-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-shirtsinbulk"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-simplybuilt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-skyatlas"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-skype"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-slack"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-slideshare"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-soundcloud"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-spotify"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-stack-exchange"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-stack-overflow"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-steam"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-steam-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-stumbleupon"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-stumbleupon-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tencent-weibo"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-trello"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tumblr"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-tumblr-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-twitch"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-twitter"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-twitter-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-viacoin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-vimeo-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-vine"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-vk"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-wechat"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-weibo"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-weixin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-whatsapp"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-windows"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-wordpress"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-xing"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-xing-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-yahoo"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-yelp"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-youtube"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-youtube-play"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-youtube-square"></i></li>';
			$tmq_icons_set .= "\n\t\t" . '</ul>';
			$tmq_icons_set .= "\n\t\t" . '<ul data-page="other">';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ambulance"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-automobile"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bicycle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cab"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-car"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-fighter-jet"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-motorcycle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plane"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rocket"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ship"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-space-shuttle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-subway"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-taxi"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-train"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-truck"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-wheelchair"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-circle-thin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-genderless"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-double"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-stroke"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-stroke-h"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mars-stroke-v"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-mercury"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-neuter"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-transgender"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-transgender-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-venus"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-venus-double"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-venus-mars"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-archive-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-audio-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-code-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-excel-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-image-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-movie-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-pdf-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-photo-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-picture-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-powerpoint-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-sound-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-text"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-text-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-video-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-word-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-file-zip-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-bitcoin"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-btc"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-cny"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-dollar"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-eur"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-euro"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-gbp"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ils"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-inr"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-jpy"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-krw"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-money"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rmb"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rouble"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rub"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ruble"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-rupee"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-shekel"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-sheqel"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-try"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-turkish-lira"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-usd"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-won"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-yen"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-arrows-alt"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-backward"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-compress"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-eject"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-expand"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-fast-backward"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-fast-forward"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-forward"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-pause"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-play"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-play-circle"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-play-circle-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-step-backward"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-step-forward"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-stop"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-youtube-play"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-ambulance"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-h-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-heart"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-heart-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-heartbeat"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-hospital-o"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-medkit"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-plus-square"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-stethoscope"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-user-md"></i></li>';
			$tmq_icons_set .= "\n\t\t\t" . '<li><i class="fa fa-wheelchair"></i></li>';				
			$tmq_icons_set .= "\n\t\t" . '</ul>';
			$tmq_icons_set .= "\n\t" . '</div>';
			$tmq_icons_set .= '</div>';
			$tmq_icons_set .= '<div class="icons-preview">';
			$tmq_icons_set .= '<span class="icon-zoom"><i class="fa ' . $value . '"></i></span>';
			$tmq_icons_set .= '<span class="icon-name">' . $value . '</span>';
			$tmq_icons_set .= '</div>';
			return $tmq_icons_set;
		}
		add_shortcode_param('tmq_icon_select', 'tmq_icon_select_settings_field', plugin_dir_url( __FILE__ ) . '/js/tmq_icon_select.js' );

		vc_map(
			array(
				'name' 			=> 'Font Awesome Icon',
				'base' 			=> 'tmq_icon',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Add a nice icon',
				'icon'			=> 'icon-wpb-tmq_icon',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'tmq_icon_select',
					  'heading' 		=> 'Icon Name',
					  'param_name' 		=> 'icon',
					  'admin_label' 	=> true,
					  'value' 			=> 'fa-cogs',
					  'description' 	=> 'Choose the icon that you want to be shown here'
					),
					array(
						'type' 			=> 'dropdown',
						'heading' 		=> 'Icon Size',
						'param_name'	=> 'size',
						'value' 		=> array( 'Normal ( 70px )' => 'normal', 'Large ( 100px )' => 'large', 'Small ( 30px )' => 'small' )
					)			
				)
			)	
		);

		/* ======================================================
		// Accordions / Update VC Accordions
		====================================================== */
		vc_add_param( 'vc_accordion_tab', array(
						'type' 				=> 'tmq_icon_select',
						'heading' 			=> 'Icon Name',
						'param_name' 		=> 'icon',
						'holder' 			=> 'div',
						'value' 			=> 'fa-question',
						'description' 		=> 'Choose the icon that you want to be shown here'
					)
		);

		//vc_remove_param( 'vc_accordion', 'active_tab' );
		vc_remove_param( 'vc_accordion', 'collapsible' );

		/* ======================================================
		// Team Members
		====================================================== */
		function tmq_teammembers( $atts, $content=null) {
			extract(shortcode_atts(array(
				'item_title'	=> '',
				'grid_columns'	=> '3',
				'items'			=> '18',
				'order_item'	=> 'date',
				'carousel'		=> '',
				'department'	=> '',
				'order_type'	=> 'ASC'
				), $atts));

			$teammembers = '';
			
			// Responsive Layout or not?
			if ( function_exists( 'ot_get_option' ) ) {
				$tmq_responsive_layout = ot_get_option( 'tmq_responsive_layout' );
			} else {
				// fallback
				$tmq_responsive_layout = 'on';
			}

			// Number of columns. We use it later.
			$cols = $grid_columns;
			
			switch( $grid_columns )	{
				case '1': 
					$grid_columns = 'col-md-12';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-12';
					}
					break;
				case '2': 
					$grid_columns = 'col-md-6';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-6';
					}
					break;
				case '3': 
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					break;
				case '4': 
					$grid_columns = 'col-md-3';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-3';
					}
					break;
				default:
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					$cols = 3;
					break;
			}
			

			$randcode = rand(1000, 20000);
			
			$teammembers_counter = 0;
			
				$teammembers .= '<div class="staff-box">';
				$teammembers .= ( empty( $item_title ) || $item_title == ' ' ) ? '<h3>&nbsp;</h3>' : "\n\t" . '<h3>' . $item_title . '</h3>';
				if ( $carousel == '1' ) {
					// Carousel is Enabled
					$teammembers .= "\n\t" . '<div id="carousel-example-generic3-'. $randcode .'" class="carousel slide" data-ride="carousel">';
					$teammembers .= "\n\t\t" . '<div class="carousel-inner">';
				}
					$members = new WP_Query(array(
						'post_type' 		=> array('team-members'),
						'orderby' 			=> $order_item,
						'order' 			=> $order_type,
						'posts_per_page' 	=> $items,
						'department'		=> $department,
						'post_status'		=> 'publish'
					));
					global $post;
					if ($members->have_posts()) :
						while ($members->have_posts()) : 
							$members->the_post();
							
							$teammembers_counter++;
							
							$tmq_memberposition 	= get_post_meta($post->ID, 'tmq_memberposition', true);
							
							// Social Information
							$tmq_memberfacebook 	=  get_post_meta($post->ID, 'tmq_memberfacebook', true);
							$tmq_membergoogleplus	=  get_post_meta($post->ID, 'tmq_membergoogleplus', true);
							$tmq_membertwitter 		=  get_post_meta($post->ID, 'tmq_membertwitter', true);
							$tmq_memberemailaddress =  get_post_meta($post->ID, 'tmq_memberemailaddress', true);
							$tmq_memberweburl 		=  get_post_meta($post->ID, 'tmq_memberweburl', true);
							$tmq_memberlinkedin		=  get_post_meta($post->ID, 'tmq_memberlinkedin', true);
							$tmq_memberphone		=  get_post_meta($post->ID, 'tmq_memberphone', true);

							// Get Post Thumbnail - If it's not empty get values
							$large_image_url = '';
							if ( '' != get_the_post_thumbnail() ) {
								$large_image_url_array = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'masonry');
								if ( is_array( $large_image_url_array ) ) {
									$large_image_url = $large_image_url_array[0];
								}
								$team_image = get_the_post_thumbnail($post->ID, 'masonry'); 
							}
							
							// columns settings (carousel pagination)
							if ( $teammembers_counter == 1 ) {
							// If it's the beginning row, it should be active!
									$teammembers .= '<div class="item active">';
									$teammembers .= "\n\t" . '<div class="row">';
							} elseif ( is_int( ( $teammembers_counter - 1 ) / $cols ) ) {
							// If it's the start of if it's on 3, 5, 7 ... or 4, 7, 10 ...
									$teammembers .= '<div class="item">';
									$teammembers .= "\n\t" . '<div class="row">';
							}															
							$teammembers .= '
								<div class="'. $grid_columns .'">
									<div class="staff-post">
										<div class="staff-post-gal">
											<ul class="staf-social">';
												if ( !empty( $tmq_memberweburl) && $tmq_memberweburl != 'none' ) { 										
													$teammembers .= '<li><a class="website" href="'. $tmq_memberweburl .'" target="_blank"><i class="fa fa-link"></i></a></li>';
												}
												if ( !empty( $tmq_memberemailaddress) && $tmq_memberemailaddress != 'none' ) {
													$teammembers .= '<li><a class="email" href="mailto:'. $tmq_memberemailaddress .'" target="_blank"><i class="fa fa-envelope-o"></i></a></li>';
												}
												if ( !empty( $tmq_memberfacebook) && $tmq_memberfacebook != 'none' ) { 										
													$teammembers .= '<li><a class="facebook" href="'. $tmq_memberfacebook .'" target="_blank"><i class="fa fa-facebook"></i></a></li>';
												}
												if ( !empty( $tmq_membertwitter) && $tmq_membertwitter != 'none' ) { 										
													$teammembers .= '<li><a class="twitter" href="'. $tmq_membertwitter .'" target="_blank"><i class="fa fa-twitter"></i></a></li>';
												}
												if ( !empty( $tmq_membergoogleplus) && $tmq_membergoogleplus != 'none' ) { 										
													$teammembers .= '<li><a class="google" href="'. $tmq_membergoogleplus .'" target="_blank"><i class="fa fa-google-plus"></i></a></li>';
												}
												if ( !empty( $tmq_memberlinkedin) && $tmq_memberlinkedin != 'none' ) { 										
													$teammembers .= '<li><a class="linkedin" href="'. $tmq_memberlinkedin .'" target="_blank"><i class="fa fa-linkedin"></i></a></li>';
												}	
												if ( !empty( $tmq_memberphone) && $tmq_memberphone != 'none' ) { 										
													$teammembers .= '<li><a data-toggle="tooltip" data-placement="top" title="'. $tmq_memberphone .'" class="phone" href="tel:'. $tmq_memberphone .'" target="_blank"><i class="fa fa-phone"></i></a></li>';
												}									
											$teammembers .= '</ul>';
											if ( '' != get_the_post_thumbnail() ) {
												$teammembers .= $team_image;
											}
										$teammembers .= '</div>
										<div class="staff-post-content">
											<h5>' . get_the_title() .'</h5>
											<span>'. $tmq_memberposition .'</span>
										</div>
									</div>
								</div>';
								if ( is_int( $teammembers_counter / $cols ) ) {
								// If it's the end. if it's on 2, 4, 6 ... or 3, 6, 9 ...
										$teammembers .= '</div>';
										$teammembers .= "\n\t" . '</div>';
								}															
							endwhile;
							if ( !is_int( $teammembers_counter / $cols ) ) {
							// If it's done without closing the row in the last condition (it didn't finished on a round number)
										$teammembers .= '</div>';
										$teammembers .= "\n\t" . '</div>';
							} 
					endif;
					wp_reset_query();
							
				// Create the final output string
				$teammembers .= "\n\t\t" . '</div>';
				if ( $carousel == '1' ) {
					// Carousel is enabled
					$teammembers .= "\n\t\t" . '<!-- Controls -->';
					$teammembers .= "\n\t\t" . '<a class="left carousel-control" href="#carousel-example-generic3-'. $randcode .'" data-slide="prev">';
					$teammembers .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-left"></span>';
					$teammembers .= "\n\t\t" . '</a>';
					$teammembers .= "\n\t\t" . '<a class="right carousel-control" href="#carousel-example-generic3-'. $randcode .'" data-slide="next">';
					$teammembers .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-right"></span>';
					$teammembers .= "\n\t\t" . '</a>';
					$teammembers .= "\n\t" . '</div>';
					$teammembers .= '</div>';
				}

			return $teammembers;
		}
		add_shortcode("tmq_teammembers", "tmq_teammembers");  

		function tmq_departments_settings_field( $settings, $value ) {
			$dependency = vc_generate_dependencies_attributes( $settings );
			$categories = get_terms('department');
			$option = '';
			$selected_input = '';
			foreach ($categories as $category) {
				$selected = '';
				if ( strpos( $value, $category->slug ) !== false ) {
					$selected = ' selected="selected"';
					$selected_input .= $category->slug;
				}
				$option .= '<option value="'.$category->slug.'"' . $selected . '>';
				$option .= $category->name;
				$option .= ' ('.$category->count.')';
				$option .= '</option>';
			}
			if ( empty( $option ) ) {
				return 'Oops! Sorry but no departments are created yet so we will show all team members.<br>';
			} else {
				return '<div class="edit_form_line department_selector">'
				.'<input type="hidden" name="' . $settings['param_name'] . '" value="' . $selected_input . '" class="wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . '_field" ' . $dependency . '>'
				.'<select multiple="multiple" name="' . $settings['param_name'] . '_fake" class="">'
				. $option
				.'</select>';
			}
		}
		add_shortcode_param('tmq_departments', 'tmq_departments_settings_field', plugin_dir_url( __FILE__ ) . '/js/tmq_teammembers.js' );

		vc_map(
			array(
				'name' 			=> 'Team Members',
				'base' 			=> 'tmq_teammembers',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'List of team members',
				'icon'			=> 'icon-wpb-tmq_teammembers',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Block Title',
					  'param_name' 		=> 'item_title',
					  'value' 			=> 'Our Staff',
					  'description' 	=> 'Enter the title of this widget block'
					),			
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Total Items',
					  'param_name' 		=> 'items',
					  'value' 			=> '9',
					  'description' 	=> 'Enter the number of team members that you want to show on this page'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Grid Columns',
					  'param_name' 		=> 'grid_columns',
					  'admin_label' 	=> true,
					  'value' 			=> array( '3 Columns' => '3', '2 Columns' => '2', '1 Column' => '1' ),
					  'description' 	=> 'Number of team members columns'
					),
					array(
						'type' 			=> 'checkbox',
						'heading' 		=> 'Carousel View',
						'param_name'	=> 'carousel',
						'value' 		=> array('Yes Show them in Carousel View!' => true )
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order by',
					  'param_name' 		=> 'order_item',
					  'value' 			=> array( 'Date' => 'date', 'Member Name' => 'title', 'Random' => 'rand' ),
					  'description' 	=> 'Number of team members columns'
					),
					array(
					  'type' 			=> 'tmq_departments',
					  'heading' 		=> 'Choose Department',
					  'param_name' 		=> 'department',
					  'value' 			=> '',
					  'description' 	=> 'Filter team members by their department'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order Type',
					  'param_name' 		=> 'order_type',
					  'value' 			=> array( 'Ascending' => 'ASC', 'Descending' => 'DESC' ),
					  'description' 	=> 'Sort order'
					)
				)
			)	
		);

		/* ======================================================
		// Clients Carousel
		====================================================== */
		function tmq_clients( $atts, $content=null) {
			extract(shortcode_atts(array(
				'item_title'	=> '',
				'grid_columns'	=> '4',
				'postid'		=> '',
				), $atts));

			$clientscarousel = '';
			
			// Number of columns. We use it later.
			$cols = $grid_columns;
			
			$clients_counter = 0;
			
				$clientscarousel .= '<div class="clients-section">';
				$clientscarousel .= ( empty( $item_title ) || $item_title == ' ' ) ? '<h3>&nbsp;</h3>' : "\n\t" . '<h3>' . $item_title . '</h3>';
				$clientscarousel .= "\n\t" . '<div id="carousel-example-generic-'. $postid .'" class="carousel slide" data-ride="carousel">';
				$clientscarousel .= "\n\t\t" . '<div class="carousel-inner">';

				$clients_q = get_post( $postid );
				if ( $clients_q ) :
					$tmq_clients_group = get_post_meta( $postid, 'tmq_clients_list', true );
					$clients_counter = 0;
					if ( is_array( $tmq_clients_group ) ) {
						foreach ( $tmq_clients_group as $tmq_client_item ) {
							$clients_counter++;
							
							// columns settings (carousel pagination)
							if ( $clients_counter == 1 ) {
							// If it's the beginning row, it should be active!
									$clientscarousel .= '<div class="item active">';
									$clientscarousel .= "\n\t" . '<ul class="partner-list grid-' . $grid_columns . '">';
							} elseif ( is_int( ( $clients_counter - 1 ) / $cols ) ) {
							// If it's the start of if it's on 3, 5, 7 ... or 4, 7, 10 ...
									$clientscarousel .= '<div class="item">';
									$clientscarousel .= "\n\t" . '<ul class="partner-list grid-' . $grid_columns . '">';
							}
							
							if ( $tmq_client_item['tmq_clients_website'] != 'none' && !empty( $tmq_client_item['tmq_clients_website']) ) {
								$linkurl = $tmq_client_item['tmq_clients_website'];
							} else { 
								$linkurl = 'javascript:void(0);';
							}
							$clientscarousel .= '<li><a href="' . $linkurl . '" target="_blank"><img src="'. $tmq_client_item['tmq_clients_logo'] .'" title="'. $tmq_client_item['title'] .'" alt="'. $tmq_client_item['title'] .'"></a></li>';
							
							if ( is_int( $clients_counter / $cols ) ) {
								// If it's the end. if it's on 2, 4, 6 ... or 3, 6, 9 ...
								$clientscarousel .= '</ul>';
								$clientscarousel .= "\n\t" . '</div>';
							}
						}
					}
				endif;
				
				if ( !is_int( $clients_counter / $cols ) ) {
				// If it's done without closing the row in the last condition (it didn't finished on a round number)
					$clientscarousel .= '</ul>';
					$clientscarousel .= "\n\t" . '</div><!-- End on non-round number -->';
				} 					

				// Create the final output string
				$clientscarousel .= "\n\t\t" . '</div>';
				$clientscarousel .= "\n\t\t" . '<!-- Controls -->';
				$clientscarousel .= "\n\t\t" . '<a class="left carousel-control" href="#carousel-example-generic-'. $postid .'" data-slide="prev">';
				$clientscarousel .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-left"></span>';
				$clientscarousel .= "\n\t\t" . '</a>';
				$clientscarousel .= "\n\t\t" . '<a class="right carousel-control" href="#carousel-example-generic-'. $postid .'" data-slide="next">';
				$clientscarousel .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-right"></span>';
				$clientscarousel .= "\n\t\t" . '</a>';
				$clientscarousel .= "\n\t" . '</div>';
				$clientscarousel .= '</div><!--Clients End-->';

			return $clientscarousel;
		}
		add_shortcode("tmq_clients", "tmq_clients");  

		function tmq_clientstype_settings_field( $settings, $value ) {
			$dependency = vc_generate_dependencies_attributes( $settings );
			$option = '';
			$q = new WP_Query(array(
				'post_type'			=> array('tmq-clients'),
				'posts_per_page' 	=> 100						
			));
			while ($q->have_posts()) : $q->the_post();
				$selected = '';
				$this_id = get_the_ID();
				if ( $this_id == $value ) {
					$selected = ' selected="selected"';
				}
				$option .= '<option value="' . get_the_ID() .'"'. $selected .'>' . get_the_title() .'</option>';
			endwhile;
			wp_reset_query();
			if ( empty( $option ) ) {
				return 'Oops! Sorry but no clients groups are created yet.<br>';
			} else {
				return '<div class="edit_form_line clients_selector">'
				.'<select name="' . $settings['param_name'] . '" class="wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . '_field" ' . $dependency . '>'
				. $option
				.'</select>';
			}
		}
		add_shortcode_param('tmq_clientstype', 'tmq_clientstype_settings_field' );

		vc_map(
			array(
				'name' 			=> 'Clients Carousel',
				'base' 			=> 'tmq_clients',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Clients carousel block',
				'icon'			=> 'icon-wpb-tmq_clients',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Block Title',
					  'param_name' 		=> 'item_title',
					  'value' 			=> 'Our Clients',
					  'description' 	=> 'Enter the title of this widget block'
					),			
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Grid Columns',
					  'param_name' 		=> 'grid_columns',
					  'admin_label' 	=> true,
					  'value' 			=> array( '4 Columns ( Recommended )' => '4', '6 Columns' => '6', '3 Columns' => '3', '2 Columns' => '2' ),
					  'description' 	=> 'Number of clients to show in one slide'
					),
					array(
					  'type' 			=> 'tmq_clientstype',
					  'heading' 		=> 'Clients Group',
					  'param_name' 		=> 'postid',
					  'value' 			=> '',
					  'description' 	=> 'Choose clients group to show'
					)
				)
			)	
		);

		/* ======================================================
		// Pricing Tables
		====================================================== */
		function tmq_pricetable( $atts, $content=null) {
			extract(shortcode_atts(array(
				'item_title'	=> '',
				'grid_columns'	=> '3',
				'postid'		=> '',
				), $atts));

			$pricetable = '';
			
			// Responsive Layout or not?
			if ( function_exists( 'ot_get_option' ) ) {
				$tmq_responsive_layout = ot_get_option( 'tmq_responsive_layout' );
			} else {
				// fallback
				$tmq_responsive_layout = 'on';
			}

			// Number of columns. We use it later.
			$cols = $grid_columns;
			
			switch( $grid_columns )	{
				case '1': 
					$grid_columns = 'col-md-12';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-12';
					}
					break;
				case '2': 
					$grid_columns = 'col-md-6';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-6';
					}
					break;
				case '3': 
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					break;
				case '4': 
					$grid_columns = 'col-md-3';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-3';
					}
					break;
				default:
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					$cols = 3;
					break;
			}
			
			$pricetable_counter = 0;
				$pricetable .= '<div class="pricing-box">';
				$pricetable .= ( empty( $item_title ) || $item_title == ' ' ) ? '<h3>&nbsp;</h3>' : "\n\t" . '<h3>' . $item_title . '</h3>';

				$pricetable_q = get_post( $postid );
				if ( $pricetable_q ) :
					$tmq_pricetable_group = get_post_meta( $postid, 'tmq_price_item', true );
					$pricetable_counter = 0;
					if ( is_array( $tmq_pricetable_group ) ) {
						foreach ( $tmq_pricetable_group as $tmq_pricetable_item ) {
							$pricetable_counter++;

							// columns settings
							if ( $pricetable_counter == 1 ) {
							// If it's the beginning row, it should be active!
									$pricetable .= "\n\t" . '<div class="row">';
							} elseif ( is_int( ( $pricetable_counter - 1 ) / $cols ) ) {
							// If it's the start of if it's on 3, 5, 7 ... or 4, 7, 10 ...
									$pricetable .= "\n\t" . '<div class="row">';
							}
							
							// Read Values From Post Meta Boxes
							$this_pt_title = $tmq_pricetable_item['title'];
							$this_pt_price = $tmq_pricetable_item['tmq_price_item_price'];
							$this_pt_featured = $tmq_pricetable_item['tmq_price_item_featured'];
							if ( $this_pt_featured == 'off' ) {
								$this_pt_featured = ' basic';
							} else {
								$this_pt_featured = ' standard';
							}
							$this_pt_f1 = $tmq_pricetable_item['tmq_price_item_f1'];
							if ( !empty( $this_pt_f1 ) ) {
								$this_pt_f1 = '<li><p>' . $this_pt_f1 . '</p></li>';
							}
							$this_pt_f2 = $tmq_pricetable_item['tmq_price_item_f2'];
							if ( !empty( $this_pt_f2 ) ) {
								$this_pt_f2 = '<li><p>' . $this_pt_f2 . '</p></li>';
							}				
							$this_pt_f3 = $tmq_pricetable_item['tmq_price_item_f3'];
							if ( !empty( $this_pt_f3 ) ) {
								$this_pt_f3 = '<li><p>' . $this_pt_f3 . '</p></li>';
							}				
							$this_pt_f4 = $tmq_pricetable_item['tmq_price_item_f4'];
							if ( !empty( $this_pt_f4 ) ) {
								$this_pt_f4 = '<li><p>' . $this_pt_f4 . '</p></li>';
							}				
							$this_pt_f5 = $tmq_pricetable_item['tmq_price_item_f5'];
							if ( !empty( $this_pt_f5 ) ) {
								$this_pt_f5 = '<li><p>' . $this_pt_f5 . '</p></li>';
							}					
							$this_pt_f6 = $tmq_pricetable_item['tmq_price_item_f6'];
							if ( !empty( $this_pt_f6 ) ) {
								$this_pt_f6 = '<li><p>' . $this_pt_f6 . '</p></li>';
							}				
							$this_pt_button = $tmq_pricetable_item['tmq_price_item_button'];
							$this_pt_href = $tmq_pricetable_item['tmq_price_item_href'];					
							
							$pricetable .= '
									<div class="' . $grid_columns . '">
										<ul class="pricing-table' . $this_pt_featured . '">
											<li class="title">
												<p>'. $this_pt_title .'</p>
												<span>'. $this_pt_price .'</span>
											</li>
											'. $this_pt_f1 . $this_pt_f2 . $this_pt_f3 . $this_pt_f4 . $this_pt_f5 . $this_pt_f6 . '
											<li>
												<a href="'. $this_pt_href .'">'. $this_pt_button .'</a>
											</li>
										</ul>
									</div>';
							
							if ( is_int( $pricetable_counter / $cols ) ) {
								// If it's the end. if it's on 2, 4, 6 ... or 3, 6, 9 ...
								$pricetable .= "\n\t" . '</div>';
							}
						}
					}
				endif;
				
				if ( !is_int( $pricetable_counter / $cols ) ) {
				// If it's done without closing the row in the last condition (it didn't finished on a round number)
					$pricetable .= "\n\t" . '</div><!-- End on non-round number -->';
				} 					

				// Create the final output string
				$pricetable .= '</div><!-- PT End -->';

			return $pricetable;
		}
		add_shortcode("tmq_pricetable", "tmq_pricetable");  

		function tmq_pricetabletype_settings_field( $settings, $value ) {
			$dependency = vc_generate_dependencies_attributes( $settings );
			$option = '';
			$q = new WP_Query(array(
				'post_type'			=> array('tmq-pricetable'),
				'posts_per_page' 	=> 100						
			));
			while ($q->have_posts()) : $q->the_post();
				$selected = '';
				$this_id = get_the_ID();
				if ( $this_id == $value ) {
					$selected = ' selected="selected"';
				}
				$option .= '<option value="' . get_the_ID() .'"'. $selected .'>' . get_the_title() .'</option>';
			endwhile;
			wp_reset_query();
			if ( empty( $option ) ) {
				return 'Oops! Sorry but no price tables group is created yet.<br>';
			} else {
				return '<div class="edit_form_line pricetable_selector">'
				.'<select name="' . $settings['param_name'] . '" class="wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . '_field" ' . $dependency . '>'
				. $option
				.'</select>';
			}
		}
		add_shortcode_param('tmq_pricetabletype', 'tmq_pricetabletype_settings_field' );

		vc_map(
			array(
				'name' 			=> 'Price Tables',
				'base' 			=> 'tmq_pricetable',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Pricing tables',
				'icon'			=> 'icon-wpb-tmq_pricetable',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Block Title',
					  'param_name' 		=> 'item_title',
					  'value' 			=> 'Our Pricing',
					  'description' 	=> 'Enter the title of this widget block'
					),			
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Grid Columns',
					  'param_name' 		=> 'grid_columns',
					  'admin_label' 	=> true,
					  'value' 			=> array( '3 Columns' => '3', '2 Columns' => '2', '1 Column' => '1' ),
					  'description' 	=> 'Number of columns of price tables'
					),
					array(
					  'type' 			=> 'tmq_pricetabletype',
					  'heading' 		=> 'Price Table Group',
					  'param_name' 		=> 'postid',
					  'value' 			=> '',
					  'description' 	=> 'Choose price tables group to show'
					)
				)
			)	
		);

		/* ======================================================
		// Drop Caps
		====================================================== */
		function tmq_dropcaps( $atts, $content=null ) {
			extract( shortcode_atts( 
				array(
					'character' 	=> 'O',
					'first_word'	=> 'ur mission',
					'drop_text'		=> '',
					'drop_link'		=> '',
					'popup'			=> '0'
				), $atts)
			);
			if ( $popup == '1' ) {
				$target = '_blank';
			} else {
				$target = '_self';
			}
			if ( !empty( $drop_link ) ) {
				$dropcapsletter = '<div class="drop-caps"><a href="' . $drop_link . '" target="' . $target . '"><span class="icon">' . $character . '</span></a><p><span>' . $first_word . '</span> ' . $drop_text . '</p></div>';
			} else {
				$dropcapsletter = '<div class="drop-caps"><span class="icon">' . $character . '</span><p><span>' . $first_word . '</span> ' . $drop_text . '</p></div>';
			}
			return $dropcapsletter;
		}
		add_shortcode( 'tmq_dropcaps', 'tmq_dropcaps' );  

		vc_map(
			array(
				'name' 			=> 'Drop Caps Letters',
				'base' 			=> 'tmq_dropcaps',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Add content with drop caps letters',
				'icon'			=> 'icon-wpb-tmq_dropcaps',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Starting With Letter',
					  'param_name' 		=> 'character',
					  'value' 			=> 'O',
					  'description' 	=> 'Enter a character to begin text with it.'
					),
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'First Word',
					  'param_name' 		=> 'first_word',
					  'value' 			=> 'ur mission',
					  'description' 	=> 'First word continues with this. This will style differently.'
					),
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Link Drop Caps to a URL',
					  'param_name' 		=> 'drop_link',
					  'value' 			=> '',
					  'description' 	=> 'You can make a link to a page when user clicks on the drop caps letter or icon.'
					),
					array(
						'type' 			=> 'checkbox',
						'heading' 		=> 'Open link in new window',
						'param_name'	=> 'popup',
						'value' 		=> array('Yes Please!' => true )
					),
					array(
					  'type' 			=> 'textarea',
					  'heading' 		=> 'Text',
					  'param_name' 		=> 'drop_text',
					  'value' 			=> '',
					  'description' 	=> 'Enter the content of the drop caps block.'
					)
				)
			)	
		);

		/* ======================================================
		// Buttons
		====================================================== */
		vc_remove_param( 'vc_button', 'icon' );
		vc_remove_param( 'vc_button', 'color' );
		vc_remove_param( 'vc_button', 'el_class' );
		vc_add_param( 'vc_button', array(
						'type' 				=> 'dropdown',
						'heading' 			=> 'Icon Mode?',
						'param_name' 		=> 'icon_mode',
						'value' 			=> array( 'Enable' => 'enable', 'Disable' => 'disable' ),
						'description' 		=> 'Should we add icon to the button?',
					)
		);
		vc_add_param( 'vc_button', array(
						'type' 				=> 'tmq_icon_select',
						'heading' 			=> 'Choose Icon',
						'param_name' 		=> 'icon',
						'holder' 			=> 'div',
						'value' 			=> '',
						'description' 		=> 'Choose the icon that you want to be shown on the button'
					)
		);
		vc_add_param( 'vc_button', array(
						'type' 				=> 'dropdown',
						'heading' 			=> 'Choose Style',
						'param_name' 		=> 'color',
						'value' 			=> array( 'Default' => 'default', 'Light' => 'light' ),
						'description' 		=> 'Choose the button style'
					)
		);
		vc_add_param( 'vc_button', array(
						'type' 				=> 'dropdown',
						'heading' 			=> 'Button Alignment',
						'param_name' 		=> 'align',
						'value' 			=> array( 'Left' => 'left', 'Right' => 'right' ),
						'description' 		=> 'Choose the button alignment'
					)
		);


		/* ======================================================
		// Portfolio
		====================================================== */
		function tmq_portfolio( $atts, $content=null) {
			extract(shortcode_atts(array(
				'item_title'			=> '',
				'grid_columns'			=> '3',
				'items'					=> '9',
				'pagination'			=> 'multipage',
				'style'					=> 'filterable',
				'category_portfolio'	=> '',
				'order_item'			=> 'date',
				'order_type'			=> 'ASC'
				), $atts));

			// Responsive Layout or not?
			if ( function_exists( 'ot_get_option' ) ) {
				$tmq_responsive_layout = ot_get_option( 'tmq_responsive_layout' );
			} else {
				// fallback
				$tmq_responsive_layout = 'on';
			}

			// Number of columns. We use it later.
			$cols = $grid_columns;
			
			switch( $grid_columns )	{
				case '1': 
					$grid_columns = 'col-md-12';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-12';
					}
					break;
				case '2': 
					$grid_columns = 'col-md-6';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-6';
					}
					break;
				case '3': 
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					break;
				case '4': 
					$grid_columns = 'col-md-3';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-3';
					}
					break;
				default:
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					$cols = 3;
					break;
			}

			$randcode = rand(1000, 20000);
			
			$portfolio_counter = 0;
			
			$portfolio_items = '';
			
			if ( $style != 'carousel' ) {
				if ( $style != 'filterable' ) {
					$portfolio_items .= ( empty( $item_title ) || $item_title == ' ' ) ? '' : "\n\t" . '<h3 class="portfolio-normal-heading">' . $item_title . '</h3>';
				} else {
					$portfolio_items .= ( empty( $item_title ) || $item_title == ' ' ) ? '' : "\n\t" . '<h3>' . $item_title . '</h3>';
				}
				$portfolio_items .= '<div class="portfolio-box with-'. $cols .'-col">';
			}
			
			if ( $style == 'filterable' ) {
				$portfolio_items .= "\n\t" . '<ul class="filter">';
				$portfolio_items .= "\n\t\t" . '<li><a href="#" class="active" data-filter="*"><i class="fa fa-th"></i>'. __('Show All', 'vertikal_plugin') . '</a></li>';
					foreach ( get_terms('portfolio_category') as $category ){
						if ( empty( $category_portfolio ) ) {
							// Add category without any conditions
							$portfolio_items .= "\n\t\t" . '<li><a href="#" data-filter=".'. $category->slug .'">'. mb_strtoupper( $category->name ) .'</a></li>';
						} else {
							// This is limited to some categories, then why should we show all?!
							if ( strpos($category_portfolio, $category->slug) !== false ) {
								$portfolio_items .= "\n\t\t" . '<li><a href="#" data-filter=".'. $category->slug .'">'. mb_strtoupper( $category->name ) .'</a></li>';
							}
						}
					}		
				$portfolio_items .= "\n\t" . '</ul>';
			} elseif ( $style == 'carousel' ) {
				$portfolio_items .= ( empty( $item_title ) || $item_title == ' ' ) ? '<h3>&nbsp;</h3>' : "\n\t" . '<h3>' . $item_title . '</h3>';
				$portfolio_items .= "\n\t" . '<div id="carousel-example-genericx-'. $randcode .'" class="carousel slide" data-ride="carousel">';
				$portfolio_items .= "\n\t\t" . '<div class="carousel-inner">';
				$pagination = 'singlepage';
			}
			
			if ( $style != 'carousel' ) {
				// We don't need pagination for carousel mode
				if ( get_query_var('paged') ) {
					$paged = get_query_var('paged');
				} elseif ( get_query_var('page') ) {
					$paged = get_query_var('page');
				} else {
					$paged = 1;
				}
				$current_page = $paged;

				if ( is_single() ) {
					//This is normal post type so use PAGE
					$paged_var = 'page';
				} elseif ( is_page() ) {
					//This is page, so use PAGED
					$paged_var = 'paged';
				}
			} else {
				$paged = 1;
			}

			$portfolio_q = new WP_Query(array(
				'post_type' 			=> array('tmq-portfolio'),
				'orderby' 				=> $order_item,
				'order' 				=> $order_type,
				'posts_per_page' 		=> $items,
				'portfolio_category'	=> $category_portfolio,
				'paged'					=> $paged,
				'post_status'			=> 'publish',
				'ignore_sticky_posts'	=> 1		
			));
			global $post;
			if ($portfolio_q->have_posts()) :
			
				//Pagination Config
				if ( 'multipage' == $pagination ) {
					$current_page = $paged;
					$pagination_text =  paginate_links(
						array(  
							'base'         => esc_url_raw( @add_query_arg( $paged_var, '%#%' ) ),
							'format'       => '',  
							'current'      => $current_page,  
							'total'        => $portfolio_q->max_num_pages, 
							'show_all'     => false,
							'end_size'     => 1,
							'mid_size'     => 5,
							'prev_next'    => true,
							'prev_text'    => '&laquo;',  
							'next_text'    => '&raquo;',
							'type'         => 'list'
						)
					);
					
					// Set pagination variable to use it where i want
					$pagination_tmp = $pagination_text;
				} else {
					$pagination_tmp = '';
				}		
			
				if ( $style != 'carousel' ) {
					$portfolio_items .= "\n\t" . '<div class="portfolio-container">';
				}
				
				while ($portfolio_q->have_posts()) : 
					$portfolio_counter++;
					$portfolio_q->the_post();
					
					// filtering_class for isotope
					$filtering_class = '';
					$categories_name = '';
					$filtering_array = get_the_terms( $post ,'portfolio_category');
					
					if ( is_array( $filtering_array ) ) {
						foreach ( $filtering_array as $category ) {
							$filtering_class .= $category->slug . ' ';
							$categories_name .= $category->name . ' ';
						}
					}

					$src = '';
					$isotope_post_class = '';
					// Get Large Image to Zoom Or maybe video for video format
					$tmq_post_format = get_post_format( $post->ID );
					if ( $tmq_post_format == 'video' ) {
						$src = get_post_meta( $post->ID, 'tmq_video_url', true );
						if ( !empty( $src ) ) {
							$isotope_post_class = ' video';
						}
					} else {
						$src_array = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'large', false, '' );
						if ( is_array( $src_array ) ) {
							$src = $src_array[0];
						} else {
							$src = '';
						}
						$isotope_post_class = '';
					}
					
					if ( $style == 'carousel' ) {
						// columns settings (carousel pagination)
						if ( $portfolio_counter == 1 ) {
						// If it's the beginning row, it should be active!
								$portfolio_items .= '<div class="item active">';
								$portfolio_items .= "\n\t" . '<div class="row">';
						} elseif ( is_int( ( $portfolio_counter - 1 ) / $cols ) ) {
						// If it's the start of if it's on 3, 5, 7 ... or 4, 7, 10 ...
								$portfolio_items .= '<div class="item">';
								$portfolio_items .= "\n\t" . '<div class="row">';
						}															
						$portfolio_items .= '<div class="'. $grid_columns .'">';	
					}
					
					$portfolio_items .= '<div class="work-post '. $filtering_class .'">
								<div class="work-post-gal">';
									if ( has_post_thumbnail() && ! post_password_required() ) {
										$portfolio_items .= get_the_post_thumbnail($post->ID, 'slideshow');
									} 
									$portfolio_items .= '<div class="hover-box">
										<a class="zoom' . $isotope_post_class . '" href="' . $src . '"></a>
										<a class="page" href="'. get_permalink() .'"></a>
									</div>
								</div>
								<div class="work-post-content">
									<a href="'. get_permalink() .'"><h2>'. get_the_title() .'</h2></a>
									<span>'. $categories_name .'</span>
								</div>
							</div>';
							
					if ( $style == 'carousel' ) {
						$portfolio_items .= '</div>';
						if ( is_int( $portfolio_counter / $cols ) ) {
						// If it's the end. if it's on 2, 4, 6 ... or 3, 6, 9 ...
								$portfolio_items .= '</div>';
								$portfolio_items .= "\n\t" . '</div>';
						}
					}
				endwhile;
				if ( $style == 'carousel' ) {		
					if ( !is_int( $portfolio_counter / $cols ) ) {
					// If it's done without closing the row in the last condition (it didn't finished on a round number)
								$portfolio_items .= '</div>';
								$portfolio_items .= "\n\t" . '</div>';
					} 
					// Carousel is enabled
					$portfolio_items .= "\n\t" . '</div>';
					$portfolio_items .= "\n\t\t" . '<!-- Controls -->';
					$portfolio_items .= "\n\t\t" . '<a class="left carousel-control" href="#carousel-example-genericx-'. $randcode .'" data-slide="prev">';
					$portfolio_items .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-left"></span>';
					$portfolio_items .= "\n\t\t" . '</a>';
					$portfolio_items .= "\n\t\t" . '<a class="right carousel-control" href="#carousel-example-genericx-'. $randcode .'" data-slide="next">';
					$portfolio_items .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-right"></span>';
					$portfolio_items .= "\n\t\t" . '</a>';
				} else {
					$portfolio_items .= "\n\t" . '</div><!--Close Container-->';
				}
				
				if ( 'multipage' == $pagination ) {
					$portfolio_items .= $pagination_tmp;
				}
				
			endif;
			wp_reset_query();
			$portfolio_items .= "\n\t" . '</div><!--Close All-->';

			return $portfolio_items;
		}
		add_shortcode("tmq_portfolio", "tmq_portfolio");  

		function tmq_portfolio_categories_settings_field( $settings, $value ) {
			$dependency = vc_generate_dependencies_attributes( $settings );
			$categories = get_terms('portfolio_category');
			$option = '';
			$selected_input = '';
			foreach ($categories as $category) {
				$selected = '';
				if ( strpos( $value, $category->slug ) !== false ) {
					$selected = ' selected="selected"';
					$selected_input .= $category->slug . ',';
				}
				$option .= '<option value="'.$category->slug.'"' . $selected . '>';
				$option .= $category->name;
				$option .= ' ('.$category->count.')';
				$option .= '</option>';
			}
			if ( empty( $option ) ) {
				return 'Oops! Sorry but no categories are created yet so we will show all portfolio items.<br>';
			} else {
				return '<div class="edit_form_line portfolio_category_selector">'
				.'<input type="hidden" name="' . $settings['param_name'] . '" value="' . $selected_input . '" class="wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . '_field" ' . $dependency . '>'
				.'<select multiple="multiple" name="' . $settings['param_name'] . '_fake" class="">'
				. $option
				.'</select>';
			}
		}
		add_shortcode_param('tmq_portfolio_categories', 'tmq_portfolio_categories_settings_field', plugin_dir_url( __FILE__ ) . '/js/tmq_portfolio_categories.js' );

		vc_map(
			array(
				'name' 			=> 'Portfolio',
				'base' 			=> 'tmq_portfolio',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Show portfolio items',
				'icon'			=> 'icon-wpb-tmq_portfolio',			
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Block Title',
					  'param_name' 		=> 'item_title',
					  'value' 			=> 'Latest Projects',
					  'description' 	=> 'Enter the title of this widget block'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Style',
					  'param_name' 		=> 'style',
					  'admin_label' 	=> true,
					  'value' 			=> array( 'Filterable' => 'filterable', 'Carousel' => 'carousel', 'Normal' => 'normal' ),
					  'description' 	=> 'How do you want to see portfolio items on your page?'
					),			
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Grid Columns',
					  'param_name' 		=> 'grid_columns',
					  'admin_label' 	=> true,
					  'value' 			=> array( '4 Columns' => '4', '3 Columns' => '3', '2 Columns' => '2' ),
					  'description' 	=> 'Show portfolio in how many columns?'
					),
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Items Per Page',
					  'param_name' 		=> 'items',
					  'value' 			=> '9',
					  'description' 	=> 'Enter the number of portfolio items that you want to show on this page / per page'
					),			
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Pagination Type',
					  'param_name' 		=> 'pagination',
					  'admin_label' 	=> true,
					  'value' 			=> array( 'Multipage' => 'multipage', 'Single Page' => 'singlepage' ),
					  'description' 	=> 'Do you want to have pagination navigation on this block?'
					),
					array(
					  'type' 			=> 'tmq_portfolio_categories',
					  'heading' 		=> 'Choose Categories',
					  'param_name' 		=> 'category_portfolio',
					  'value' 			=> '',
					  'description' 	=> 'Filter portfolio by categories'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order by',
					  'param_name' 		=> 'order_item',
					  'value' 			=> array( 'Date' => 'date', 'Project Name' => 'title', 'Random' => 'rand' ),
					  'description' 	=> 'Sort items by'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order Type',
					  'param_name' 		=> 'order_type',
					  'value' 			=> array( 'Ascending' => 'ASC', 'Descending' => 'DESC' ),
					  'description' 	=> 'Sort order'
					)
				)
			)	
		);

		/* ======================================================
		// Blog Shortcode
		====================================================== */
		function tmq_blog( $atts, $content=null) {
			extract(shortcode_atts(array(
				'item_title'			=> '',
				'grid_columns'			=> '3',
				'show_details'			=> 'yes',
				'items'					=> '9',
				'pagination'			=> 'multipage',
				'pagination_align'		=> 'tmq_left',
				'pagination_location'	=> 'tmq_bottom',
				'style'					=> '',
				'category_filter'		=> '',
				'order_item'			=> 'date',
				'order_type'			=> 'ASC'
				), $atts));

			// Responsive Layout or not?
			if ( function_exists( 'ot_get_option' ) ) {
				$tmq_responsive_layout = ot_get_option( 'tmq_responsive_layout' );
			} else {
				// fallback
				$tmq_responsive_layout = 'on';
			}

			// Number of columns. We use it later.
			$cols = $grid_columns;
			
			switch( $grid_columns )	{
				case '1': 
					$grid_columns = 'col-md-12';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-12';
					}
					break;
				case '2': 
					$grid_columns = 'col-md-6';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-6';
					}
					break;
				case '3': 
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					break;
				case '4': 
					$grid_columns = 'col-md-3';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-3';
					}
					break;
				default:
					$grid_columns = 'col-md-4';
					if ( $tmq_responsive_layout == 'off' ) {
						$grid_columns .= ' col-xs-4';
					}
					$cols = 3;
					break;
			}
			
			$blog_counter = 0;
			$blog_output = '';
			
			$randcode = rand(1000, 2000);
			
			$blog_output .= '<div class="latest-post"><!--Start Blog-->';
			
			if ( $style == 'carousel' ) {
				$blog_output .= ( empty( $item_title ) || $item_title == ' ' ) ? '<h3>&nbsp;</h3>' : "\n\t" . '<h3>' . $item_title . '</h3>';
				$blog_output .= "\n\t" . '<div id="carousel-example-genericb-'. $randcode .'" class="carousel slide" data-ride="carousel">';
				$blog_output .= "\n\t\t" . '<div class="carousel-inner">';
				$pagination = 'singlepage';
			} else {
				$blog_output .= ( empty( $item_title ) || $item_title == ' ' ) ? '' : "\n\t" . '<h3>' . $item_title . '</h3>';	
			}
			
			if ( $style != 'carousel' ) {
				// We don't need pagination for carousel mode
				if ( get_query_var('paged') ) {
					$paged = get_query_var('paged');
				} elseif ( get_query_var('page') ) {
					$paged = get_query_var('page');
				} else {
					$paged = 1;
				}
				$current_page = $paged;

				if ( is_single() ) {
					//This is normal post type so use PAGE
					$paged_var = 'page';
				} elseif ( is_page() ) {
					//This is page, so use PAGED
					$paged_var = 'paged';
				}
			} else {
				$paged = 1;
			}

			$blog_q = new WP_Query(array(
				'post_type' 			=> array('post'),
				'orderby' 				=> $order_item,
				'order' 				=> $order_type,
				'posts_per_page' 		=> $items,
				'category_name'			=> $category_filter,
				'paged'					=> $paged,
				'post_status'			=> 'publish',
				'ignore_sticky_posts'	=> 1		
			));
			global $post;
			if ($blog_q->have_posts()) :
			
				// Posts Limit Excerpt After!
				if ( function_exists( 'ot_get_option' ) ) {
					$tmq_blogexceptlimit = ot_get_option( 'tmq_blogexceptlimit' );
					$tmq_blogexcept_after_text = ot_get_option( 'tmq_blogexcept_after_text' );
				} else {
					// fallback
					$tmq_blogexceptlimit = '40';
					$tmq_blogexcept_after_text = '';
				}		

				if ( empty( $tmq_blogexceptlimit ) ) {
					$tmq_blogexceptlimit = '40';
				}
				
				//Pagination Config
				if ( 'multipage' == $pagination ) {
				
					$top_pg_class = '';
					switch ( $pagination_align ) {
						case 'tmq_left':
						default:
							$top_pg_class = ' text-left';
							break;
						case 'tmq_center':
							$top_pg_class = ' text-center';
							break;
						case 'tmq_right':
							$top_pg_class = ' text-right';
							break;
					}
					
					$current_page = $paged;
					$pagination_text =  paginate_links(
						array(  
							'base'         => esc_url_raw( @add_query_arg( $paged_var, '%#%' ) ),
							'format'       => '',  
							'current'      => $current_page,  
							'total'        => $blog_q->max_num_pages, 
							'show_all'     => false,
							'end_size'     => 1,
							'mid_size'     => 5,
							'prev_next'    => true,
							'prev_text'    => '&laquo;',  
							'next_text'    => '&raquo;',
							'type'         => 'list'
						)
					);
					
					// Set pagination variable to use it where i want
					$pagination_tmp = '<div class="row"><div class="col-md-12 col-xs-12'. $top_pg_class .'">'. $pagination_text .'</div></div>';
				} else {
					$pagination_tmp = '';
				}
				
				// Show pagination on top of the page
				if ( $pagination_location != 'tmq_bottom' ) {
					$blog_output .= $pagination_tmp;
				}


				while ($blog_q->have_posts()) : 
					// $blog_counter++;
					$blog_q->the_post();
						
					// if ( $style == 'carousel' ) {
						// // columns settings (carousel pagination)
						// if ( $blog_counter == 1 ) {
						// // If it's the beginning row, it should be active!
								// $blog_output .= '<div class="item active">';
								// $blog_output .= "\n\t" . '<div class="row">';
						// } elseif ( is_int( ( $blog_counter - 1 ) / $cols ) ) {
						// // If it's the start of if it's on 3, 5, 7 ... or 4, 7, 10 ...
								// $blog_output .= '<div class="item">';
								// $blog_output .= "\n\t" . '<div class="row">';
						// }															
						// $blog_output .= '<div class="'. $grid_columns .'">';	
					// }

					if ( $blog_counter == 0 ) {
						if ( $style == 'carousel' ) {
							$blog_output .= '<div class="item active">';
						}
						$blog_output .= '<div class="row">';
					}
					if ( $blog_counter != 0  && is_int( $blog_counter / $cols ) ) {
						if ( $style == 'carousel' ) {
							$blog_output .= '<div class="item">';
						}			
						$blog_output .= '<div class="row">';
					}
					
					$blog_output .= '<div class="' . $grid_columns . '">';
						// Show each post by reading from it's template
						// get_template_part( 'layouts/blog/content', 'loop' );
						$blog_output .= '<div class="b-item news-item">
							<div class="inner-item"><a href="'. get_permalink() .'">';

								// Get and Show Featured Image
								if ( has_post_thumbnail() && ! post_password_required() ) {
									$blog_output .= get_the_post_thumbnail( $post->ID, 'slideshow' );
								}
								
								// Hide More info such as author name/comments and date
								if ( $show_details == 'no' ) {
									$blog_output .= '</a>';								
								} else {
									$blog_output .= '</a><div class="hover-item">
										<ul>
											<li><a class="autor" href="'. get_author_posts_url( get_the_author_meta( 'ID' ) ) .'"><i class="fa fa-user"></i>'. get_the_author() .'</a></li>
											<li><a class="date"><i class="fa fa-clock-o"></i> '. get_the_date( ) .'</a></li>';
											if ( comments_open() ) {
												$blog_output .= '<li><a class="comment-numb" href="'. get_comments_link() .'"><i class="fa fa-comments"></i> '. tmq_get_comments_count( $post->ID, __('No Comments', 'vertikal_plugin'), __('Comment', 'vertikal_plugin'), __('Comments', 'vertikal_plugin') ) .'</a></li>';
											}
										$blog_output .= '</ul>
									</div>';							
								}
								
								// Check if we should show it as a review post
								$tmq_reviewtype = get_post_meta( $post->ID, 'tmq_reviewtype', true );
								if ( $tmq_reviewtype == 'on' ) {
									$tmq_review_rating = get_post_meta( $post->ID, 'tmq_review_rating', true );
								
								$blog_output .= '<div class="list-rating">
									<div class="review-overall-rating">
										'. __('Rating', 'vertikal_plugin') .'
									</div>
									<div class="review-rate">';
										if ( is_numeric( $tmq_review_rating ) ) {
											$blog_output .= number_format($tmq_review_rating, 1);
										} else {
											$blog_output .= $tmq_review_rating;
										}
									$blog_output .= '</div>
								</div>';
								}
							$blog_output .= '</div>
							<h2><a href="'. get_permalink() .'">'. get_the_title() .'</a></h2>
							<p>'; 
								$tmq_excerpt = get_the_excerpt();
								if ( function_exists( 'tmq_string_limit_words' ) ) {
									$blog_output .= tmq_string_limit_words( $tmq_excerpt, $tmq_blogexceptlimit ) . $tmq_blogexcept_after_text;
								} else {
									$blog_output .= $tmq_excerpt;
								}
							$blog_output .= '</p>
							<a class="read-more" href="'. get_permalink() .'">'. __( 'read more', 'vertikal_plugin' ) .' <i class="fa fa-arrow-right"></i></a>
						</div>';
					$blog_output .= '</div>';

					// Add to counter
					$blog_counter++;
					
					if ( is_int( $blog_counter / $cols )  ) {
						if ( $style == 'carousel' ) {
							$blog_output .= '</div><!--end after counter-->';
						}			
						$blog_output .= '</div><!--end after counter-->';
					}	
					
				endwhile;
				
				if ( $style == 'carousel' ) {		
					if ( !is_int( $blog_counter / $cols ) ) {
					// If it's done without closing the row in the last condition (it didn't finished on a round number)
								$blog_output .= '</div>';
								$blog_output .= "\n\t" . '</div>';
					} 
					// Carousel is enabled
					$blog_output .= "\n\t" . '</div>';
					$blog_output .= "\n\t\t" . '<!-- Controls -->';
					$blog_output .= "\n\t\t" . '<a class="left carousel-control" href="#carousel-example-genericb-'. $randcode .'" data-slide="prev">';
					$blog_output .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-left"></span>';
					$blog_output .= "\n\t\t" . '</a>';
					$blog_output .= "\n\t\t" . '<a class="right carousel-control" href="#carousel-example-genericb-'. $randcode .'" data-slide="next">';
					$blog_output .= "\n\t\t\t" . '<span class="glyphicon glyphicon-chevron-right"></span>';
					$blog_output .= "\n\t\t" . '</a>';
				} else {
					if ( !is_int( $blog_counter / $cols ) ) {
					// If it's done without closing the row in the last condition (it didn't finished on a round number)
								$blog_output .= "\n\t" . '</div>';
					} 			
					$blog_output .= "\n\t" . '</div><!--Close Container-->';
				}
				
				// Show pagination on bottom of the page
				if ( $pagination_location != 'tmq_top' ) {
					$blog_output .= $pagination_tmp;
				}
				
			endif;
			wp_reset_query();
			if ( $style == 'carousel' ) {
				$blog_output .= "\n\t\t" . '</div>';
				$blog_output .= "\n\t" . '</div><!--End Carousel-->';
			}	

			return $blog_output;
		}
		add_shortcode("tmq_blog", "tmq_blog");  

		function tmq_categories_settings_field( $settings, $value ) {
			$dependency = vc_generate_dependencies_attributes( $settings );
			$categories = get_categories();
			$option = '';
			$selected_input = '';
			foreach ($categories as $category) {
				$selected = '';
				if ( strpos( $value, $category->slug ) !== false ) {
					$selected = ' selected="selected"';
					$selected_input .= $category->slug . ',';
				}
				$option .= '<option value="'.$category->slug.'"' . $selected . '>';
				$option .= $category->name;
				$option .= ' ('.$category->count.')';
				$option .= '</option>';
			}
			if ( empty( $option ) ) {
				return 'Oops! Sorry but no categories are created yet so we will show all blog posts.<br>';
			} else {
				return '<div class="edit_form_line blog_category_selector">'
				.'<input type="hidden" name="' . $settings['param_name'] . '" value="' . $selected_input . '" class="wpb_vc_param_value wpb-input wpb-select ' . $settings['param_name'] . ' ' . $settings['type'] . '_field" ' . $dependency . '>'
				.'<select multiple="multiple" name="' . $settings['param_name'] . '_fake" class="">'
				. $option
				.'</select>';
			}
		}
		add_shortcode_param('tmq_categories', 'tmq_categories_settings_field', plugin_dir_url( __FILE__ ) . '/js/tmq_categories.js' );

		vc_map(
			array(
				'name' 			=> 'Blog',
				'base' 			=> 'tmq_blog',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Show blog posts',
				'icon'			=> 'icon-wpb-tmq_blog',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Block Title',
					  'param_name' 		=> 'item_title',
					  'value' 			=> 'Latest Posts',
					  'description' 	=> 'Enter the title of this widget block'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Style',
					  'param_name' 		=> 'style',
					  'value' 			=> array( 'Normal' => 'normal', 'Carousel' => 'carousel' ),
					  'description' 	=> 'How do you want to see blog posts on your page?'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Show Post Details',
					  'param_name' 		=> 'show_details',
					  'admin_label' 	=> true,
					  'value' 			=> array( 'Yes' => 'yes', 'No' => 'no' ),
					  'description' 	=> 'Show post info such as author name, date and comments when user moves the mouse over blog item'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Grid Columns',
					  'param_name' 		=> 'grid_columns',
					  'admin_label' 	=> true,
					  'value' 			=> array( '3 Columns' => '3', '2 Columns' => '2', '1 Column' => '1' ),
					  'description' 	=> 'Show blog posts in how many columns?'
					),
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Items Per Page',
					  'param_name' 		=> 'items',
					  'value' 			=> '9',
					  'description' 	=> 'Enter the number of blog posts that you want to show on this page / per page'
					),			
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Pagination Type',
					  'param_name' 		=> 'pagination',
					  'admin_label' 	=> true,
					  'value' 			=> array( 'Multipage' => 'multipage', 'Single Page' => 'singlepage' ),
					  'description' 	=> 'Do you want to have pagination navigation on this block?'
					),		
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Pagination Alignment',
					  'param_name' 		=> 'pagination_align',
					  'value' 			=> array( 'Left' => 'tmq_left', 'Center' => 'tmq_center', 'Right' => 'tmq_right' ),
					  'description' 	=> 'Which side of the page do you want to see your pagination links?'
					),		
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Pagination Links Location',
					  'param_name' 		=> 'pagination_location',
					  'value' 			=> array( 'Before Posts' => 'tmq_top', 'After Posts' => 'tmq_bottom', 'Both of Them' => 'tmq_both' ),
					  'description' 	=> 'Where do you want to see pagination links for this block?'
					),
					array(
					  'type' 			=> 'tmq_categories',
					  'heading' 		=> 'Choose Categories',
					  'param_name' 		=> 'category_filter',
					  'value' 			=> '',
					  'description' 	=> 'Filter blog posts by categories'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order by',
					  'param_name' 		=> 'order_item',
					  'value' 			=> array( 'Date' => 'date', 'Title' => 'title', 'Most Popular' => 'comment_count', 'Last Modified' => 'modified', 'Random' => 'rand' ),
					  'description' 	=> 'Sort items by'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order Type',
					  'param_name' 		=> 'order_type',
					  'value' 			=> array( 'Ascending' => 'ASC', 'Descending' => 'DESC' ),
					  'description' 	=> 'Sort order'
					)
				)
			)	
		);

		/* ======================================================
		// Blog List
		====================================================== */
		function tmq_blog_list( $atts, $content=null) {
			extract(shortcode_atts(array(
				'items'					=> '3',
				'category_filter'		=> '',
				'order_item'			=> 'date',
				'order_type'			=> 'ASC',
				'thumbnail'				=> 'thumbnail'
				), $atts));

			$blog_list_output = '';
			
			$blog_list_output .= '<div class="tmq-list"><ul class="posts-list">';
			
			$blog_list_q = new WP_Query(array(
				'post_type' 			=> array('post'),
				'orderby' 				=> $order_item,
				'order' 				=> $order_type,
				'posts_per_page' 		=> $items,
				'category_name'			=> $category_filter,
				'post_status'			=> 'publish',
				'ignore_sticky_posts'	=> 1		
			));
			global $post;
			if ($blog_list_q->have_posts()) :
			
				while ($blog_list_q->have_posts()) : 

					$blog_list_q->the_post();
					$blog_list_output .= '<li>';
					if ( has_post_thumbnail() && ! post_password_required() ) {
						$blog_list_output .= get_the_post_thumbnail( $post->ID, 'mini' );
					}				
					$blog_list_output .= '<h6><a href="'. get_permalink() .'">'. get_the_title() .'</a></h6>';
					$blog_list_output .= '</li>';

				endwhile;
				
			endif;
			wp_reset_query();

			$blog_list_output .= '</ul></div>';
			return $blog_list_output;
		}
		add_shortcode("tmq_blog_list", "tmq_blog_list");  
		
		vc_map(
			array(
				'name' 			=> 'Blog List',
				'base' 			=> 'tmq_blog_list',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Simple list of blog posts',
				'icon'			=> 'icon-wpb-tmq_blog_list',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Number of Items',
					  'param_name' 		=> 'items',
					  'value' 			=> '3',
					  'description' 	=> 'Enter the number of blog posts that you want to show on this block.'
					),			
					array(
					  'type' 			=> 'tmq_categories',
					  'heading' 		=> 'Choose Categories',
					  'param_name' 		=> 'category_filter',
					  'value' 			=> '',
					  'description' 	=> 'Filter blog posts by categories'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order by',
					  'param_name' 		=> 'order_item',
					  'value' 			=> array( 'Date' => 'date', 'Title' => 'title', 'Most Popular' => 'comment_count', 'Last Modified' => 'modified', 'Random' => 'rand' ),
					  'description' 	=> 'Sort items by'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order Type',
					  'param_name' 		=> 'order_type',
					  'value' 			=> array( 'Ascending' => 'ASC', 'Descending' => 'DESC' ),
					  'description' 	=> 'Sort order'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Output Style',
					  'param_name' 		=> 'thumbnail',
					  'value' 			=> array( 'With Thumbnail' => 'thumbnail', 'Simple List' => 'simplelist' ),
					  'description' 	=> 'Show post thumbnail or not?'
					)
				)
			)	
		);
		/* ======================================================
		// Projects List
		====================================================== */
		function tmq_portfolio_list( $atts, $content=null) {
			extract(shortcode_atts(array(
				'items'					=> '3',
				'category_portfolio'		=> '',
				'order_item'			=> 'date',
				'order_type'			=> 'ASC',
				'thumbnail'				=> 'thumbnail'
				), $atts));

			$portfolio_list_output = '';
			
			$portfolio_list_output .= '<div class="tmq-list"><ul class="posts-list">';
			
			$portfolio_list_q = new WP_Query(array(
				'post_type' 			=> array('tmq-portfolio'),
				'orderby' 				=> $order_item,
				'order' 				=> $order_type,
				'posts_per_page' 		=> $items,
				'portfolio_category'	=> $category_portfolio,
				'post_status'			=> 'publish',
				'ignore_sticky_posts'	=> 1		
			));
			global $post;
			if ($portfolio_list_q->have_posts()) :
			
				while ($portfolio_list_q->have_posts()) : 

					$portfolio_list_q->the_post();
					$portfolio_list_output .= '<li>';
					if ( has_post_thumbnail() && ! post_password_required() ) {
						$portfolio_list_output .= get_the_post_thumbnail( $post->ID, 'mini' );
					}				
					$portfolio_list_output .= '<h6><a href="'. get_permalink() .'">'. get_the_title() .'</a></h6>';
					$portfolio_list_output .= '</li>';

				endwhile;
				
			endif;
			wp_reset_query();

			$portfolio_list_output .= '</ul></div>';
			return $portfolio_list_output;
		}
		add_shortcode("tmq_portfolio_list", "tmq_portfolio_list");  
		
		vc_map(
			array(
				'name' 			=> 'Projects List',
				'base' 			=> 'tmq_portfolio_list',
				'class' 		=> '',
				'category' 		=> 'Content',
				'weight'		=> 10,
				'description' 	=> 'Simple list of portfolio items',
				'icon'			=> 'icon-wpb-tmq_portfolio_list',
				'admin_label'	=> true,
				'params' 		=> array(
					array(
					  'type' 			=> 'textfield',
					  'heading' 		=> 'Number of Items',
					  'param_name' 		=> 'items',
					  'value' 			=> '3',
					  'description' 	=> 'Enter the number of portfolio items that you want to show on this block.'
					),			
					array(
					  'type' 			=> 'tmq_portfolio_categories',
					  'heading' 		=> 'Choose Categories',
					  'param_name' 		=> 'category_portfolio',
					  'value' 			=> '',
					  'description' 	=> 'Filter portfolio items by categories'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order by',
					  'param_name' 		=> 'order_item',
					  'value' 			=> array( 'Date' => 'date', 'Title' => 'title', 'Most Popular' => 'comment_count', 'Last Modified' => 'modified', 'Random' => 'rand' ),
					  'description' 	=> 'Sort items by'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Order Type',
					  'param_name' 		=> 'order_type',
					  'value' 			=> array( 'Ascending' => 'ASC', 'Descending' => 'DESC' ),
					  'description' 	=> 'Sort order'
					),
					array(
					  'type' 			=> 'dropdown',
					  'heading' 		=> 'Output Style',
					  'param_name' 		=> 'thumbnail',
					  'value' 			=> array( 'With Thumbnail' => 'thumbnail', 'Simple List' => 'simplelist' ),
					  'description' 	=> 'Show post thumbnail or not?'
					)
				)
			)	
		);

		/* ======================================================
		// Services
		====================================================== */
		function tmq_contactinfo($atts, $content=null) {
			extract(shortcode_atts(
				array(
					'phone'  		=> '',
					'email'	 		=> '',
					'address'  	 	=> '',
					'linkhref' 	 	=> '#',
					'css_animation' => ''
				), $atts)
			); 
			
			$contactinfo = '';
			
			$css_class = getCSSAnimation( $css_animation );
			
			$contactinfo .= '<ul class="contact-list '. $css_class .'">';
			$contactinfo .= ( empty( $phone ) ? '' : "\n\t\t" . '<li><a class="phone" href="'. $linkhref .'"><i class="fa fa-phone"></i>' . $phone . '</a></li>' );
			$contactinfo .= ( empty( $email ) ? '' : "\n\t\t" . '<li><a class="mail" href="'. $linkhref .'"><i class="fa fa-envelope"></i>' . $email . '</a></li>' );
			$contactinfo .= ( empty( $address ) ? '' : "\n\t\t" . '<li><a class="address" href="'. $linkhref .'"><i class="fa fa-home"></i>' . $address . '</a></li>' );
			$contactinfo .= '</ul>';
			
			return $contactinfo;
		}
		add_shortcode("tmq_contactinfo", "tmq_contactinfo");  

		vc_map( 
			array(
				'name' 			=> 'Contact Info',
				'base' 			=> 'tmq_contactinfo',
				'category' 		=> 'Content',
				'weight'		=> 10,		
				'description' 	=> 'Stylish contact info',
				'icon'			=> 'icon-wpb-tmq_contactinfo',
				'params' => array(
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Phone Number',
						'param_name' 	=> 'phone',
						'description' 	=> 'Enter phone number here.',
						'value'			=> '9930 1234 5678',
						'admin_label'	=> true,
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Email Address',
						'param_name' 	=> 'email',
						'description' 	=> 'Enter email address here.',
						'value' 		=> 'contact@company.com'
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Address',
						'param_name' 	=> 'address',
						'description' 	=> 'Enter address here',
						'value' 		=> 'street address example'
					),
					array(
						'type' 			=> 'textfield',
						'heading' 		=> 'Link to Page',
						'param_name' 	=> 'linkhref',
						'description' 	=> 'Click event href URL',
						'value' 		=> '#'
					),
					$add_css_animation
				)
			) 
		); 

		/* Remove Elements From VC */
		vc_remove_element('vc_widget_sidebar');
		vc_remove_element('vc_tour');
		vc_remove_element('vc_progress_bar');
		vc_remove_element('vc_toggle');
		vc_remove_element('vc_posts_grid');
		vc_remove_element('vc_pie');
		vc_remove_element('vc_separator');
		vc_remove_element('vc_images_carousel');
		vc_remove_element('vc_text_separator');
		vc_remove_element('vc_carousel');
		vc_remove_element('vc_cta_button');

		/* Change Classes? */
		function tmq_use_bootstrap_3_classes($class_string, $tag) {
			if ($tag=='vc_row' || $tag=='vc_row_inner') {
				$class_string = str_replace('vc_row-fluid', 'row', $class_string);
			}

			// Responsive Layout or not?
			if ( function_exists( 'ot_get_option' ) ) {
				$tmq_responsive_layout = ot_get_option( 'tmq_responsive_layout' );
			} else {
				// fallback
				$tmq_responsive_layout = 'on';
			}			
			
			if ($tag=='vc_column' || $tag=='vc_column_inner') {
				if ( $tmq_responsive_layout == 'off' ) {
					$class_string = preg_replace('/vc_span(\d{1,2})/', 'col-md-$1 col-xs-$1', $class_string);
				} else {
					$class_string = preg_replace('/vc_span(\d{1,2})/', 'col-md-$1', $class_string);
				}
			}
			return $class_string;
		}
		// Filter to Replace default css class for vc_row shortcode and vc_column
		add_filter('vc_shortcodes_css_class', 'tmq_use_bootstrap_3_classes', 10, 2);
	}
}
?>